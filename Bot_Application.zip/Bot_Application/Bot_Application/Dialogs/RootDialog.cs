﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;

namespace Bot_Application.Dialogs
{
    [Serializable]
    public class RootDialog : IDialog<object>
    {
        public Task StartAsync(IDialogContext context)
        {
            context.Wait(MessageReceivedAsync);

            return Task.CompletedTask;
        }

        private async Task MessageReceivedAsync(IDialogContext context, IAwaitable<object> result)
        {
            var activity = await result as Activity;

            int length = (activity.Text ?? string.Empty).Length;

            var date = activity.LocalTimestamp;

            activity.ServiceUrl = "asos.com";

            var url = activity.ServiceUrl;

            if (activity.Text == ("how r u?"))
            {
                await context.PostAsync("I am fine");
            }

            else if (activity.Text == "date?")
            {
                await context.PostAsync($"{date}");
            }

            else if (activity.Text == "take me to asos")
            {
                await context.PostAsync($"{url}");
            }
            
            else if (int.TryParse(activity.Text,out int result1))
            {
                int count = 0;
                int x = Convert.ToInt32(activity.Text);
                var productid = 2;
                while(count >= 0 && count <= 1)
                {
                    var bargainvalue = checkbargainvlaue(x, productid);
                    if (bargainvalue)
                    {
                        await context.PostAsync("Congrats!!! you have successfully won the bargain. BArgain Code will be generated soon... ");
                        var bargaincode = generatebargaincode(productid);
                        await context.PostAsync($"your bargain code is {bargaincode}");
                    }
                    else
                        await context.PostAsync("Sorry!!! you have lost the bargain..try one more luck ");
                    count++;
                }

                    await context.PostAsync("Sorry!!! you have exhausted the limit..!! ");
            }
            else
            {
                await context.PostAsync($"Please enter a valid bargain price ");
            }

            context.Wait(MessageReceivedAsync);
        }

        private bool checkbargainvlaue(int userprice,int productid)
        {
            var bargainprice = 0;
            var originalprice = 0;
            var connection = new SqlConnection();
            connection.ConnectionString = @"Data Source=(LocalDb)\MSSQLLocalDB;Initial Catalog=nikhil;Integrated Security=True";
            var command = new SqlCommand();
            command.Connection = connection;
            command.CommandType = CommandType.Text;
            command.CommandText = "select originalprice,bargainprice from bargain where productid=@productid";

            command.Parameters.Add("productid", SqlDbType.Int).Value = productid;

            connection.Open();
            SqlDataReader reader = command.ExecuteReader();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    originalprice = reader.GetInt32(0);

                    bargainprice = reader.GetInt32(1);
                }
            }

            if (userprice <= originalprice && userprice >= bargainprice)
            {
                return true;
            }
            return false;
        }
        private string generatebargaincode(int productid)
        {
            Random random = new Random();
            int randomNumberprev = random.Next(0, 100);
            var randomNumber = $"asos{randomNumberprev}"; 
            var connection = new SqlConnection();
            connection.ConnectionString = @"Data Source=(LocalDb)\MSSQLLocalDB;Initial Catalog=nikhil;Integrated Security=True";
            connection.Open();
            var command = new SqlCommand();
            command.Connection = connection;
            command.CommandType = CommandType.Text;

            command.CommandText = $"update bargain set bargaincode = '{randomNumber}' where productid={productid}";

            command.ExecuteNonQuery();
            return randomNumber;
        }
    }
}